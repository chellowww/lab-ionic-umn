import { Component } from '@angular/core';
import { Todo, TodoService } from '../todo.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
todos: Todo[];
  constructor( private todoService: TodoService) {}

  ngOnInit() {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.todoService.getTodos().subscribe(res => {
      this.todos = res;

    });
  }

  remove(item) {
    this.todoService.removeTodo(item.id);
  }

}
